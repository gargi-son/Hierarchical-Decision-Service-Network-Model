import copy
import json
import importlib.util
import sys

# sys.path.append("/Users/alexbrodsky/Documents/OneDrive - George Mason University - O365 Production/aaa_python_code/aaa_dgalPy")
sys.path.append("/Users/garson/Desktop/Dex/Fall 2022/CS787/Exam/cs787_ha3_and_exam_sn_template")
import lib.dgalPy as dgal

# import aaa_dgalPy.lib.dgalPy as dgal

#--------------------------------------------------------------
# updated to include optional upper bound as well
# this function returns true if, for all flow ids f in flow
# 1. qty >= 0
# 2. if there's a lower bound for f in flowBounds, qty >= lb
# 3. if there's an upper bound for f in flowBounds, qty <= ub
# and returns false otherwise.
# Note: must use dgal.all for aggregating constraints (boolean and)
# replace below w/correct implementation
def flowBoundConstraint(flowBounds,flow):
    return True

#--------------------------------------------------------------
def atomicSeqDiff(setA,setB):
    return [a for a in setA if all([b != a for b in setB])]
#--------------------------------------------------------------

def am(input):
    shared = input["shared"]
    root = input["rootService"]
    services = input["services"]

    serviceMetrics = computeMetrics(shared,root,services)

    cost = serviceMetrics[root]["cost"]
    co2 = serviceMetrics[root]["co2"]
    constraints = serviceMetrics[root]["constraints"]

    return {
        "cost": cost,
        "co2": co2,
        "constraints": constraints,
        "rootService": root,
        "services": serviceMetrics
    }
#--------------------------------------------------------------------
#assumptions on input data for ns:computeMetrics:
#1. root service inFlows and outFlows are disjoint
#2. every inFlow of every subService must have a corresponding root inFlow
#   and/or a corresponding subService outFlow (i.e., an inFlow of a subService can't
#   come from nowhere)
#3. every outFlow of every subService must have a corresponding root outFlow
#   and/or a corresponding subService inFlows (i.e., an outFlow of a subService can't
#  go nowhere)
#4. every root outFlow must have at least one corresponding subService outFlow
#5. every root inFlow must have at least one corresponding subService inFlow
#----------------------------------------------------------------

def computeMetrics(shared,root,services):
    type = services[root]["type"]
    inFlow = services[root]["inFlow"]
    outFlow = services[root]["outFlow"]

    if type == "supplier":
        return {root: supplierMetrics(services[root])}
    elif type == "manufacturer":
        return {root: manufMetrics(services[root])}
    elif type == "transport":
        return {root: transportMetrics(services[root],shared)}
    else:

        subServices = services[root]["subServices"]
        subServiceMetrics = dgal.merge([computeMetrics(shared,s,services) for s in subServices])
#--------------------
# replace below with a correct cost computation

        cost = 0
        for service in subServiceMetrics:
            if subServiceMetrics[service]['type'] != 'composite':
                cost = cost + subServiceMetrics[service]['cost']
        # print("Printing cost:", cost)
#--------------------
# new for exam: replace below with a correct co2 computation

        co2 = 0
        for service in subServiceMetrics:
            if subServiceMetrics[service]['type'] != 'composite':
                co2 = co2 + subServiceMetrics[service]['co2']

        # print("\nPrinting co2: ", co2)
#--------------------
# compute the set union of inFlow and outFlow keys of the root service

        inOutFlowKeysSet = {**inFlow, **outFlow}
        # print("\nPrinting inOutFlowKeysSet", inOutFlowKeysSet)
#--------------------
# compute the set of all flow ids from
# inFlow and outFlow of the root service, as well as from inFlow and outFlow of all subServices

##################!!!!!!!!!!!!!!!!!!!!!!!!!#####################################
######################Implementation 1 #########################################

        combined_set = {}
        for s in services[root]['subServices']:
            combined_set.update({**services[s]['inFlow'], **services[s]['outFlow']})
        flowKeysSet = {**inOutFlowKeysSet, **combined_set}
        # print("\nPrintng flowKeysSet", flowKeysSet)

#################!!!!!!!!!!!!!!!!!!!!!!!!#######################################
###################implementation 2 ############################################
        #
        # # flowKeysSet = {"tbd"}
        # flowKeysSet = []
        # # flowKeysSet_outFlow = []
        # # flowKeysSet_inFlow = []
        # for x in services.keys():
        #     if x == root:
        #         for s in services[x]["subServices"]:
        #             for o in (services[s]["inFlow"].keys()):
        #                 if o not in flowKeysSet:
        #                     flowKeysSet.append(o)
        #             for o in (services[s]["outFlow"].keys()):
        #                 if o not in flowKeysSet:
        #                     flowKeysSet.append(o)
        # # print("Printing flowKeysSet for root: ",root, flowKeysSet)
#--------------------
# below is the set of flow ids from inFlow and outFlow of subServices, so that these
# flow ids do not appear in inFlow or outFlow of the root service

        internalOnlyFlowKeysSet = set(flowKeysSet).difference(inOutFlowKeysSet)
        # print("\nPrinting internalOnlyFlowKeysSet", internalOnlyFlowKeysSet)
#--------------------
# below complete/fix the computation of the dictionary subServiceFlowSupply,
# which gives, for every flow f in flowKeysSet, the total quantity of flow f
# coming from all subServices in their outFlow


##################!!!!!!!!!!!!!!!!!!!!!!!!!#####################################
######################Implementation 1 #########################################

        subServicesFlowSupply = dict()
        for f in flowKeysSet:
            supply = 0
            for s in subServiceMetrics:
                if f in subServiceMetrics[s]['outFlow'] and subServiceMetrics[s]['type'] != 'composite':
                    supply = supply + subServiceMetrics[s]['outFlow'][f]['qty']

            subServicesFlowSupply.update({f: supply})
        # print("\nPrinting subServicesFlowSupply", subServicesFlowSupply)

#################!!!!!!!!!!!!!!!!!!!!!!!!#######################################
###################implementation 2 ############################################
        #
        # subServicesFlowSupply = dict()
        # for f in flowKeysSet:
        #     supply = 0
        #     found=False
        #     for x in services.keys():
        #         if x == root and x!="mySupplyChain":
        #             for s in services[x]["subServices"]:
        #                 if "orders" in services[s].keys():
        #                     for o in services[s]["orders"]:
        #                         if f==o["out"]:
        #                             if f in subServicesFlowSupply.keys():
        #                                 supply=subServicesFlowSupply[f]+o["qty"]
        #                                 subServicesFlowSupply.update({f: supply})
        #                             else:
        #                                 found=True
        #                                 supply=o["qty"]
        #                                 subServicesFlowSupply.update({f: supply})
        #                 else:
        #                     for o in services[s]["outFlow"].keys():
        #                         if f==o:
        #                             if f in subServicesFlowSupply.keys():
        #                                 supply=subServicesFlowSupply[f]+services[s]["outFlow"][f]["qty"]
        #                                 subServicesFlowSupply.update({f: supply})
        #                             else:
        #                                 found=True
        #                                 supply=services[s]["outFlow"][f]["qty"]
        #                                 subServicesFlowSupply.update({f: supply})
        #     if found==False:
        #         subServicesFlowSupply.update({f: supply})
        # # print("before mysupply",subServicesFlowSupply)
        # for f in flowKeysSet:
        #     supply = 0
        #     found=False
        #     for x in services.keys():
        #         if x == root and x =="mySupplyChain":
        #             for p in services[x]["subServices"]:
        #                 for s in services[p]["subServices"]:
        #                     if "orders" in services[s].keys():
        #                         for o in services[s]["orders"]:
        #                             if f==o["out"]:
        #                                 if f in subServicesFlowSupply.keys():
        #                                     supply=subServicesFlowSupply[f]+o["qty"]
        #                                     subServicesFlowSupply.update({f: supply})
        #                                 else:
        #                                     found=True
        #                                     supply=o["qty"]
        #                                     subServicesFlowSupply.update({f: supply})
        #                     else:
        #                         for o in services[s]["outFlow"].keys():
        #                             if f==o:
        #                                 if f in subServicesFlowSupply.keys():
        #                                     supply=subServicesFlowSupply[f]+services[s]["outFlow"][f]["qty"]
        #                                     subServicesFlowSupply.update({f: supply})
        #                                 else:
        #                                     found=True
        #                                     supply=services[s]["outFlow"][f]["qty"]
        #                                     subServicesFlowSupply.update({f: supply})

#--------------------
# below complete/fix the computation of the dictionary subServiceFlowDemand,
# which gives, for every flow f in flowKeysSet, the total quantity of flow f
# coming into all subServices in their inFlow

#################!!!!!!!!!!!!!!!!!!!!!!!!#######################################
###################implementation 1 ############################################

        subServicesFlowDemand = dict()
        for f in flowKeysSet:
            demand = 0
            for s in subServiceMetrics:
                if f in subServiceMetrics[s]['inFlow'] and subServiceMetrics[s]['type'] != 'composite':
                    demand = demand + subServiceMetrics[s]['inFlow'][f]['qty']

            subServicesFlowDemand.update({f: demand})
        # print("\nPrinting subServicesFlowDemand", subServicesFlowDemand)


#################!!!!!!!!!!!!!!!!!!!!!!!!#######################################
###################implementation 2 ############################################
        #
        # subServicesFlowDemand = dict()
        # for f in flowKeysSet:
        #     demand = 0
        #     found=False
        #     for x in services.keys():
        #         if x == root and x!="mySupplyChain":
        #             for s in services[x]["subServices"]:
        #                 if "orders" in services[s].keys():
        #                     for o in services[s]["orders"]:
        #                         if f==o["in"]:
        #                             if f in subServicesFlowDemand.keys():
        #                                 demand=subServicesFlowDemand[f]+o["qty"]
        #                                 subServicesFlowDemand.update({f: demand})
        #                             else:
        #                                 found=True
        #                                 demand=o["qty"]
        #                                 subServicesFlowDemand.update({f: demand})
        #                 else:
        #                     for o in services[s]["inFlow"].keys():
        #                         if f==o:
        #                             if "qty" in services[s]["inFlow"][o].keys():
        #                                 if f in subServicesFlowDemand.keys():
        #                                     demand=subServicesFlowDemand[f]+services[s]["inFlow"][f]["qty"]
        #                                     subServicesFlowDemand.update({f: demand})
        #                                 else:
        #                                     found=True
        #                                     demand=services[s]["inFlow"][f]["qty"]
        #                                     subServicesFlowDemand.update({f: demand})
        #     if found==False:
        #         subServicesFlowDemand.update({f: demand})
        # # print("\nFor demand: before mydemand",subServicesFlowDemand)
        # for f in flowKeysSet:
        #     demand = 0
        #     found=False
        #     for x in services.keys():
        #         if x == root and x =="mySupplyChain":
        #             for p in services[x]["subServices"]:
        #                 for s in services[p]["subServices"]:
        #                     if "orders" in services[s].keys():
        #                         for o in services[s]["orders"]:
        #                             if f==o["in"]:
        #                                 if f in subServicesFlowDemand.keys():
        #                                     demand=subServicesFlowDemand[f]+o["qty"]
        #                                     subServicesFlowDemand.update({f: demand})
        #                                 else:
        #                                     found=True
        #                                     demand=o["qty"]
        #                                     subServicesFlowDemand.update({f: demand})
        #                     else:
        #                         for o in services[s]["inFlow"].keys():
        #                             if f==o:
        #                                 if "qty" in services[s]["inFlow"][o].keys():
        #                                     if f in subServicesFlowDemand.keys():
        #                                         demand=subServicesFlowDemand[f]+services[s]["inFlow"][f]["qty"]
        #                                         subServicesFlowDemand.update({f: demand})
        #                                     else:
        #                                         found=True
        #                                         demand=services[s]["inFlow"][f]["qty"]
        #                                         subServicesFlowDemand.update({f: demand})

#--------------------
# below complete/fix the computation of newInFlow,
# which is a dictionary with the same keys as inFlow;
# for every key f in inFlow, the value in newInFlow is a dictionary of the form
# {"qty": qty, "item": item}, where item is taken from inFlow,
# and you need to correctly compute qty
# (hint: use subServicesFlowSupply and subServicesFlowDemand)

#################!!!!!!!!!!!!!!!!!!!!!!!!#######################################
###################implementation 1 ############################################

        newInFlow = dict()
        for f in inFlow:
            qty = subServicesFlowDemand[f]
            newInFlow.update({f:{"qty":qty, "item": inFlow[f]["item"]}})
        # print("\nPrinting newInFlow", newInFlow)

# #--------------------
# below complete/fix the computation of newOutFlow,
# which is a dictionary with the same keys as outFlow;
# for every key f in outFlow, the value in newOutFlow is a dictionary of the form
# {"qty": qty, "item": item}, where item is taken from outFlow,
# and you need to correctly compute qty
# (hint: use subServicesFlowSupply and subServicesFlowDemand)

#################!!!!!!!!!!!!!!!!!!!!!!!!#######################################
###################implementation 1 ############################################

        newOutFlow = dict()
        for f in outFlow:
            qty = subServicesFlowSupply[f]
            newOutFlow.update({f:{"qty":qty, "item": outFlow[f]["item"]}})
        # print("\nPrinting newOutFlow", newOutFlow)
#        dgal.debug("newInFlow",newInFlow)
#---------------------
# below complete/fix the computation of constraint (must return Boolean value)
# that for every flow f in internalOnlyFlowKeysSet, the total "supplied" qty of f,
# i.e., coming from all subServices in their outFlow, is greater then or equal
# the total "demand" qty of f, i.e., coming into all subServices in their inFlow
        internalSupplySatisfiesDemand = dgal.all([
            True
            for f in internalOnlyFlowKeysSet
            if subServicesFlowSupply[f] > subServicesFlowDemand[f]
        ])
#---------------------
# below are the flowBoundConstraints, which use the corresponding function
# you need to implement - see above, including enforcing lower and upper bound
# of qtys in flows

        inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
        outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)
        subServiceConstraints = dgal.all([ subServiceMetrics[s]["constraints"]
                                        for s in subServices
        ])
#---------------------
        on = services[root]["on"]
        noSubServices = len(subServices)
#--------------------
# new: below compute the number of activeSubServices, i.e., subServices in which the "on" flag is 1.
# note: you can't use "on" flag var in an if-then-else condition, as it may be a decision variable
# in optimization

        noActiveSubServices = 0
        for s in subServices:
            if (not dgal.flagZeroIffValueZero(0, subServiceMetrics[s]['on'], 1)):
                noActiveSubServices = noActiveSubServices + 1
#--------------------
# the following constraint (using dgal function flagZeroIffValueZero) expresses the condition
# that the binary flag is 0 if and only if the number of active services is 0.
# noSubServices is an upper bound for noActiveServices

        activeServiceConstraint = dgal.flagZeroIffValueZero(on, noActiveSubServices, noSubServices)
#--------------------
# new: below express the constraint activeSubServicesBound that is True if and only if
# 1. there's no "maxActiveSubServices" key under root service, or
# 2. the number of active sub-services is bounded by maxActiveSubServices (value corresponding to this
# key under the root service)

        activeSubServicesBound = True

#--------------------

        constraints = dgal.all([ internalSupplySatisfiesDemand,
                            inFlowConstraints,
                            outFlowConstraints,
                            subServiceConstraints,
                            activeServiceConstraint,
                            activeSubServicesBound
                      ])

#       dgal.debug("constraints", constraints)
        rootMetrics = {
            root : {
                "type": type,
                "on": on,
                "cost": cost,
                "co2": co2,
                "constraints": constraints,
                "internalSupplySatisfiesDemand": internalSupplySatisfiesDemand,
                "subServiceConstraints": subServiceConstraints,
                "activeServiceConstraint": activeServiceConstraint,
                 "inFlow": newInFlow,
                "outFlow": newOutFlow,
                "subServices": subServices
            }
        }
        return dgal.merge([ subServiceMetrics , rootMetrics ])

# end of Compute Metrics function
# ------------------------------------------------------------------------------
def supplierMetrics(supInput):
    type = supInput["type"]
    inFlow = supInput["inFlow"]
    outFlow = supInput["outFlow"]
    on = supInput["on"]

#------------
# replace below with correct computation
# this part did not change compared w/HA3

    cost=0
    for m in outFlow.keys():
        val_m = outFlow[m]
        cost = cost + (outFlow[m]['qty'] * outFlow[m]['ppu'])
        #cost=cost+val_m['qty'] * val_m['ppu']

    newOutFlow_trial={}
    for m in outFlow.keys():
         #val_m = outFlow[m]
         obj={}
         obj["qty"]=outFlow[m]['qty']
         obj["item"]=outFlow[m]['item']
         newOutFlow_trial[m]=obj

    newOutFlow = newOutFlow_trial
    constraints = flowBoundConstraint(outFlow,newOutFlow)
#-----------------
# new: replace below with correct computation
    co2 = 0
    for k in outFlow.keys():
        co2 = co2 + (outFlow[k]["co2pu"] * outFlow[k]["qty"])
    # print("##############Printing the co2 value",co2)
#-----------------
    boundConstraints = flowBoundConstraint(outFlow,newOutFlow)
#-----------------
# new: replace below with correct computation
    totalQtyOut = 0
    for k in outFlow.keys():
        totalQtyOut = totalQtyOut + outFlow[k]["qty"]
        # print("Printng the total quantity", totalQtyOut)
#-----------------
# the constraint below expresseses that the "on" flag of supplier service is 0
# if and only if the total quantity (in all outFlow) is zero
# 1000000 is used as the overall upper bound on total quantity

    activeServiceConstraint = dgal.flagZeroIffValueZero(on, totalQtyOut, 1000000 )
# ------------------
    constraints = dgal.all([ boundConstraints, activeServiceConstraint])

    return {
        "type": type,
        "on": on,
        "cost": cost,
        "co2": co2,
        "constraints": constraints,
        "boundConstraints": boundConstraints,
        "activeServiceConstraint": activeServiceConstraint,
        "inFlow": dict(),
        "outFlow": newOutFlow
    }
#---------------------------------------------------------------------------------------
# simple manufacturer
# assumption: there is an input flow for every inQtyPer1out

def manufMetrics(manufInput):
    type = manufInput["type"]
    inFlow = manufInput["inFlow"]
    outFlow = manufInput["outFlow"]
    qtyInPer1out = manufInput["qtyInPer1out"]
    on = manufInput["on"]

#-------------
# replace below with correct computation
# this part did not change compared w/HA3
    cost = 0
    for m in outFlow.keys():
        cost=cost+outFlow[m]['qty'] * outFlow[m]['ppu']

    newInFlow={}
    for x in qtyInPer1out.keys():
        for i in qtyInPer1out[x].keys():
            if i in newInFlow.keys():
                newInFlow[i]['qty']= newInFlow[i]['qty'] + (outFlow[x]['qty']*qtyInPer1out[x][i])
            else:
                newInFlow[i]={
                       "qty": (outFlow[x]['qty']*qtyInPer1out[x][i]),
                      "item": inFlow[i]['item']
                    }
    newOutFlow = {}
    for o in outFlow.keys():
         for i in outFlow[o].keys():
            newOutFlow[o] = {
                "qty": outFlow[o]['qty'],
                "item": outFlow[o]['item']
            }

#---------------
# new: replace with correct computation
    co2 = 0
    for k in outFlow.keys():
        co2 = co2 + (outFlow[k]["co2pu"] * outFlow[k]["qty"])
    # print("Printing co2 for co2pu: ",outFlow[k]["co2pu"] , "and qty: ", outFlow[k]["qty"], co2)
#----------------

    inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
    outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)
    boundConstraints = dgal.all([ inFlowConstraints, outFlowConstraints])
#---------------
# new: replace below with correct computation

    totalQtyOut = 0
    for k in outFlow.keys():
        totalQtyOut = totalQtyOut + outFlow[k]["qty"]
        # print("Printing the totalQtyOut ", totalQtyOut, "for key", k)

#----------------
# the following constraint expresses that the "on" flag is 0 if and only if
# the total qty out (from all outFlow) is 0
# 1000000 is used as an upper bound on total qty out
    activeServiceConstraint = dgal.flagZeroIffValueZero(on, totalQtyOut, 1000000 )
#----------------
    constraints = dgal.all([ boundConstraints, activeServiceConstraint])

    return { "type": type,
             "on": on,
             "cost": cost,
             "co2": co2,
             "constraints": constraints,
             "boundConstraints": boundConstraints,
             "activeServiceConstraint": activeServiceConstraint,
             "inFlow": newInFlow,
             "outFlow": newOutFlow
    }
# end of manufMetrics
def transportMetrics(transportInput, shared):
    type = transportInput["type"]
    inFlow = transportInput["inFlow"]
    outFlow = transportInput["outFlow"]
    pplbFromTo = transportInput["pplbFromTo"]
    co2perlbFromTo = transportInput["co2perlbFromTo"]
    orders = transportInput["orders"]
    on = transportInput["on"]

#------------------
# the part below did not change compared w/HA3
# replace below with correct implementation. Note: it is based on transportation orders

    newInFlow={}
    for od in orders:
        for o in inFlow.keys():
            if od['in'] in newInFlow.keys():
                newInFlow[od['in']]['qty'] = newInFlow[od['in']]['qty'] + od['qty']
                break
            else:
                newInFlow[od['in']]={
                    'qty': od['qty'],
                    'item':inFlow[o]['item']
                    }
                break;

    newOutFlow = {}
    total_qty = 0
    for od in orders:
        for o in outFlow.keys():
            if od['out'] in newOutFlow.keys():
                newOutFlow[od['out']]['qty'] = newOutFlow[od['out']]['qty'] + od['qty']
                break;
            else:
                newOutFlow[od['out']]={
                    'qty': od['qty'],
                    'item': outFlow[o]['item']
                    }
                break;

# replace below with computation of all source locations
    sourceLocations = "TBD"
# replace below with computation of a structure for all source-destination pairs in orders
    destsPerSource = "TBD"
#------------------
# new: replace below with computation that returns a structure that gives, for every source-destination pair,
# 1. weight of shipment from source to destination
# 2. cost of shipment from source to destination, based on weight and price per pound (pplb)
# 3. co2 of shipment from source to destination, based on weight and co2 per pound (co2perlb)
#  according to orders

    weightCostCo2PerSourceDest = "TBD"
#--------------
# replace below with transportation cost computation, based on, for each source-destination pair,
# on total weight and price per pound (pplb)

    cost = 0
    item_list={}
    for k in inFlow.keys():
        if inFlow[k]["item"] in item_list:
            item_list[inFlow[k]["item"]].append(k)
        else:
            item_list[inFlow[k]["item"]]=[k]

    for o in orders:
        for r in item_list.keys():
            if o["in"] in item_list[r]:
                cost=cost+(o['qty']*shared['items'][r]['weight']* pplbFromTo[shared["busEntities"][o["sender"]]["loc"]][shared["busEntities"][o["recipient"]]["loc"]])
    # print("Printing costtt", cost)


#-----------------
# new: replace below with correct computation

    co2 = 0
    item_list={}
    for k in inFlow.keys():
        if inFlow[k]["item"] in item_list:
            item_list[inFlow[k]["item"]].append(k)
        else:
            item_list[inFlow[k]["item"]]=[k]

    for o in orders:
        for r in item_list.keys():
            if o["in"] in item_list[r]:
                co2 = co2+(o['qty']*shared['items'][r]['weight']* co2perlbFromTo[shared["busEntities"][o["sender"]]["loc"]][shared["busEntities"][o["recipient"]]["loc"]])
    # print("Printing co2",co2)

#-----------------
    inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
    outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)
    boundConstraints = dgal.all([inFlowConstraints,outFlowConstraints])
#-----------------
# new: replace below with computation of total qty of shipped items in all orders
    totalOrderQty = 0
    for o in orders:
        # print("Printing quantity", o["qty"])
        totalOrderQty = totalOrderQty + o["qty"]
    # print("Printing totalOrderQty", totalOrderQty)
#-----------------
# the following constraint exrpesses the condition that the "on" flag for transportation
# service is 0 if and only if the total shipment qty (in all orders) is 0
# 1000000 is used as the upper bound on the total shipment qty

    activeServiceConstraint = dgal.flagZeroIffValueZero(on, totalOrderQty, 1000000 )
#-----------------
    constraints = dgal.all([ boundConstraints, activeServiceConstraint])
    return { "type": type,
             "on": on,
             "cost": cost,
             "co2": co2,
             "constraints": constraints,
             "boundConstraints": boundConstraints,
             "activeServiceConstraint": activeServiceConstraint,
             "inFlow": newInFlow,
             "outFlow": newOutFlow
             }
# end of transportMetrics
#----------------
def combinedSupply(input):
    return am(input)
def combinedManuf(input):
    return am(input)
def combinedTransp(input):
    return am(input)
