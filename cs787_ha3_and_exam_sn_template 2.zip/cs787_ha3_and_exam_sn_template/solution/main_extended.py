#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
# sys.path.append(r'//Users/alexbrodsky/Documents/OneDrive\ -\ George\ Mason\ University\ -\ O365\ Production/aaa_python_code')
sys.path.append(r'/lib')
import copy
import pyomo.environ as pyo
from pyomo.environ import *
import json
import ams_extended as ams
sys.path.append("/Users/alexbrodsky/Documents/OneDrive - George Mason University - O365 Production/aaa_python_code/cs787_ha3_supp_manuf_transp_sn_solution")
import lib.dgalPy as dgal

# import aaa_dgalPy.lib.dgalPy as dgal
# import importlib.util
# spec = importlib.util.spec_from_file_location("dgal", "/Users/alexbrodsky/Documents/OneDrive - George Mason University - O365 Production/aaa_python_code/aaa_dgalPy/lib/dgalPy.py")
# dgal = importlib.util.module_from_spec(spec)
# spec.loader.exec_module(dgal)
dgal.startDebug()
input = json.loads(sys.stdin.read())
answer = ams.am(input)
sys.stdout.write(json.dumps(answer))
