import copy
import json
import importlib.util
import sys

# sys.path.append("/Users/alexbrodsky/Documents/OneDrive - George Mason University - O365 Production/aaa_python_code/aaa_dgalPy")
sys.path.append("/Users/alexbrodsky/Documents/OneDrive - George Mason University - O365 Production/aaa_python_code/cs787_ha3_supp_manuf_transp_sn_solution")
import lib.dgalPy as dgal

# import aaa_dgalPy.lib.dgalPy as dgal

#--------------------------------------------------------------
# updated to include optional upper bound as well
# this function returns true if, for all flow ids f in flow
# 1. qty >= 0
# 2. if there's a lower bound for f in flowBounds, qty >= lb
# 3. if there's an upper bound for f in flowBounds, qty <= ub
# and returns false otherwise.
# Note: must use dgal.all for aggregating constraints (boolean and)
# replace below w/correct implementation
def flowBoundConstraint(flowBounds,flow):
    return True

#--------------------------------------------------------------
def atomicSeqDiff(setA,setB):
    return [a for a in setA if all([b != a for b in setB])]
#--------------------------------------------------------------

def am(input):
    shared = input["shared"]
    root = input["rootService"]
    services = input["services"]

    serviceMetrics = computeMetrics(shared,root,services)

    cost = serviceMetrics[root]["cost"]
    co2 = serviceMetrics[root]["co2"]
    constraints = serviceMetrics[root]["constraints"]

    return {
        "cost": cost,
        "co2": co2,
        "constraints": constraints,
        "rootService": root,
        "services": serviceMetrics
    }
#--------------------------------------------------------------------
#assumptions on input data for ns:computeMetrics:
#1. root service inFlows and outFlows are disjoint
#2. every inFlow of every subService must have a corresponding root inFlow
#   and/or a corresponding subService outFlow (i.e., an inFlow of a subService can't
#   come from nowhere)
#3. every outFlow of every subService must have a corresponding root outFlow
#   and/or a corresponding subService inFlows (i.e., an outFlow of a subService can't
#  go nowhere)
#4. every root outFlow must have at least one corresponding subService outFlow
#5. every root inFlow must have at least one corresponding subService inFlow
#----------------------------------------------------------------

def computeMetrics(shared,root,services):
    type = services[root]["type"]
    inFlow = services[root]["inFlow"]
    outFlow = services[root]["outFlow"]

    if type == "supplier":
        return {root: supplierMetrics(services[root])}
    elif type == "manufacturer":
        return {root: manufMetrics(services[root])}
    elif type == "transport":
        return {root: transportMetrics(services[root],shared)}
    else:

        subServices = services[root]["subServices"]
        subServiceMetrics = dgal.merge([computeMetrics(shared,s,services) for s in subServices])
#--------------------
# replace below with a correct cost computation
        cost = 1000
#--------------------
# new for exam: replace below with a correct co2 computation
        co2 = 1000
#--------------------
# compute the set union of inFlow and outFlow keys of the root service
        inOutFlowKeysSet = {"tbd"}
#--------------------
# compute the set of all flow ids from
# inFlow and outFlow of the root service, as well as from inFlow and outFlow of all subServices
        flowKeysSet = {"tbd"}
#--------------------
# below is the set of flow ids from inFlow and outFlow of subServices, so that these
# flow ids do not appear in inFlow or outFlow of the root service
        internalOnlyFlowKeysSet = set(flowKeysSet).difference(inOutFlowKeysSet)
#--------------------
# below complete/fix the computation of the dictionary subServiceFlowSupply,
# which gives, for every flow f in flowKeysSet, the total quantity of flow f
# coming from all subServices in their outFlow

        subServicesFlowSupply = dict()
        for f in flowKeysSet:
            supply = 1000
            subServicesFlowSupply.update({f: supply})
#--------------------
# below complete/fix the computation of the dictionary subServiceFlowDemand,
# which gives, for every flow f in flowKeysSet, the total quantity of flow f
# coming into all subServices in their inFlow

        subServicesFlowDemand = dict()
        for f in flowKeysSet:
            demand = 1000
            subServicesFlowDemand.update({f: demand})
#--------------------
# below complete/fix the computation of newInFlow,
# which is a dictionary with the same keys as inFlow;
# for every key f in inFlow, the value in newInFlow is a dictionary of the form
# {"qty": qty, "item": item}, where item is taken from inFlow,
# and you need to correctly compute qty
# (hint: use subServicesFlowSupply and subServicesFlowDemand)

        newInFlow = dict()
        for f in inFlow:
            qty = 1000
            newInFlow.update({f:{"qty":qty, "item": inFlow[f]["item"]}})
#--------------------
# below complete/fix the computation of newOutFlow,
# which is a dictionary with the same keys as outFlow;
# for every key f in outFlow, the value in newOutFlow is a dictionary of the form
# {"qty": qty, "item": item}, where item is taken from outFlow,
# and you need to correctly compute qty
# (hint: use subServicesFlowSupply and subServicesFlowDemand)
        newOutFlow = dict()
        for f in outFlow:
            qty = 1000
            newOutFlow.update({f:{"qty":qty, "item": outFlow[f]["item"]}})
#        dgal.debug("newInFlow",newInFlow)
#---------------------
# below complete/fix the computation of constraint (must return Boolean value)
# that for every flow f in internalOnlyFlowKeysSet, the total "supplied" qty of f,
# i.e., coming from all subServices in their outFlow, is greater then or equal
# the total "demand" qty of f, i.e., coming into all subServices in their inFlow
        internalSupplySatisfiesDemand = dgal.all([
            True
            for f in internalOnlyFlowKeysSet
        ])
#---------------------
# below are the flowBoundConstraints, which use the corresponding function
# you need to implement - see above, including enforcing lower and upper bound
# of qtys in flows

        inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
        outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)
        subServiceConstraints = dgal.all([ subServiceMetrics[s]["constraints"]
                                        for s in subServices
        ])
#---------------------
        on = services[root]["on"]
        noSubServices = len(subServices)
#--------------------
# new: below compute the number of activeSubServices, i.e., subServices in which the "on" flag is 1.
# note: you can't use "on" flag var in an if-then-else condition, as it may be a decision variable
# in optimization

        noActiveSubServices = 10
#--------------------
# the following constraint (using dgal function flagZeroIffValueZero) expresses the condition
# that the binary flag is 0 if and only if the number of active services is 0.
# noSubServices is an upper bound for noActiveServices

        activeServiceConstraint = dgal.flagZeroIffValueZero(on, noActiveSubServices, noSubServices)
#--------------------
# new: below express the constraint activeSubServicesBound that is True if and only if
# 1. there's no "maxActiveSubServices" key under root service, or
# 2. the number of active sub-services is bounded by maxActiveSubServices (value corresponding to this
# key under the root service)

        activeSubServicesBound = True

#--------------------

        constraints = dgal.all([ internalSupplySatisfiesDemand,
                            inFlowConstraints,
                            outFlowConstraints,
                            subServiceConstraints,
                            activeServiceConstraint,
                            activeSubServicesBound
                      ])

#       dgal.debug("constraints", constraints)
        rootMetrics = {
            root : {
                "type": type,
                "on": on,
                "cost": cost,
                "co2": co2,
                "constraints": constraints,
                "internalSupplySatisfiesDemand": internalSupplySatisfiesDemand,
                "subServiceConstraints": subServiceConstraints,
                "activeServiceConstraint": activeServiceConstraint,
                 "inFlow": newInFlow,
                "outFlow": newOutFlow,
                "subServices": subServices
            }
        }
        return dgal.merge([ subServiceMetrics , rootMetrics ])

# end of Compute Metrics function
# ------------------------------------------------------------------------------
def supplierMetrics(supInput):
    type = supInput["type"]
    inFlow = supInput["inFlow"]
    outFlow = supInput["outFlow"]
    on = supInput["on"]

#------------
# replace below with correct computation
# this part did not change compared w/HA3

    cost = 1000
    newOutFlow = "TBD"

#-----------------
# new: replace below with correct computation
    co2 = 1000
#-----------------
    boundConstraints = flowBoundConstraint(outFlow,newOutFlow)
#-----------------
# new: replace below with correct computation
    totalQtyOut = 1000
#-----------------
# the constraint below expresseses that the "on" flag of supplier service is 0
# if and only if the total quantity (in all outFlow) is zero
# 1000000 is used as the overall upper bound on total quantity

    activeServiceConstraint = dgal.flagZeroIffValueZero(on, totalQtyOut, 1000000 )
# ------------------
    constraints = dgal.all([ boundConstraints, activeServiceConstraint])

    return {
        "type": type,
        "on": on,
        "cost": cost,
        "co2": co2,
        "constraints": constraints,
        "boundConstraints": boundConstraints,
        "activeServiceConstraint": activeServiceConstraint,
        "inFlow": dict(),
        "outFlow": newOutFlow
    }
#---------------------------------------------------------------------------------------
# simple manufacturer
# assumption: there is an input flow for every inQtyPer1out

def manufMetrics(manufInput):
    type = manufInput["type"]
    inFlow = manufInput["inFlow"]
    outFlow = manufInput["outFlow"]
    qtyInPer1out = manufInput["qtyInPer1out"]
    on = manufInput["on"]

#-------------
# replace below with correct computation
# this part did not change compared w/HA3
    cost = 1000
    newInFlow = "TBD"
    newOutFlow = "TBD"
#---------------
# new: replace with correct computation
    co2 = 1000
#----------------

    inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
    outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)
    boundConstraints = dgal.all([ inFlowConstraints, outFlowConstraints])
#---------------
# new: replace below with correct computation

    totalQtyOut = 1000
#----------------
# the following constraint expresses that the "on" flag is 0 if and only if
# the total qty out (from all outFlow) is 0
# 1000000 is used as an upper bound on total qty out
    activeServiceConstraint = dgal.flagZeroIffValueZero(on, totalQtyOut, 1000000 )
#----------------
    constraints = dgal.all([ boundConstraints, activeServiceConstraint])

    return { "type": type,
             "on": on,
             "cost": cost,
             "co2": co2,
             "constraints": constraints,
             "boundConstraints": boundConstraints,
             "activeServiceConstraint": activeServiceConstraint,
             "inFlow": newInFlow,
             "outFlow": newOutFlow
    }
# end of manufMetrics
def transportMetrics(transportInput, shared):
    type = transportInput["type"]
    inFlow = transportInput["inFlow"]
    outFlow = transportInput["outFlow"]
    pplbFromTo = transportInput["pplbFromTo"]
    co2perlbFromTo = transportInput["co2perlbFromTo"]
    orders = transportInput["orders"]
    on = transportInput["on"]

#------------------
# the part below did not change compared w/HA3
# replace below with correct implementation. Note: it is based on transportation orders
    newInFlow = "TBD"
    newOutFlow = "TBD"
# replace below with computation of all source locations
    sourceLocations = "TBD"
# replace below with computation of a structure for all source-destination pairs in orders
    destsPerSource = "TBD"
#------------------
# new: replace below with computation that returns a structure that gives, for every source-destination pair,
# 1. weight of shipment from source to destination
# 2. cost of shipment from source to destination, based on weight and price per pound (pplb)
# 3. co2 of shipment from source to destination, based on weight and co2 per pound (co2perlb)
#  according to orders

    weightCostCo2PerSourceDest = "TBD"
#--------------
# replace below with transportation cost computation, based on, for each source-destination pair,
# on total weight and price per pound (pplb)

    cost = 1000
#-----------------
# new: replace below with correct computation


    co2 = 1000
#-----------------
    inFlowConstraints = flowBoundConstraint(inFlow,newInFlow)
    outFlowConstraints = flowBoundConstraint(outFlow,newOutFlow)
    boundConstraints = dgal.all([inFlowConstraints,outFlowConstraints])
#-----------------
# new: replace below with computation of total qty of shipped items in all orders
    totalOrderQty = 1000
#-----------------
# the following constraint exrpesses the condition that the "on" flag for transportation
# service is 0 if and only if the total shipment qty (in all orders) is 0
# 1000000 is used as the upper bound on the total shipment qty

    activeServiceConstraint = dgal.flagZeroIffValueZero(on, totalOrderQty, 1000000 )
#-----------------
    constraints = dgal.all([ boundConstraints, activeServiceConstraint])
    return { "type": type,
             "on": on,
             "cost": cost,
             "co2": co2,
             "constraints": constraints,
             "boundConstraints": boundConstraints,
             "activeServiceConstraint": activeServiceConstraint,
             "inFlow": newInFlow,
             "outFlow": newOutFlow
             }
# end of transportMetrics
#----------------
def combinedSupply(input):
    return am(input)
def combinedManuf(input):
    return am(input)
def combinedTransp(input):
    return am(input)
